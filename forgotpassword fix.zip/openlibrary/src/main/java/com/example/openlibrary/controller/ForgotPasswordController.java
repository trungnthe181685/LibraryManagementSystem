package com.example.openlibrary.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.SimpleMailMessage;
import com.example.openlibrary.model.User;
import com.example.openlibrary.repository.UserRepository;


@Controller
public class ForgotPasswordController {

//    @Autowired
//    private UserRepository userRepository;
//
//    @Autowired
//    private JavaMailSender mailSender;
//
//    @PostMapping("/forgotpassword")
//    public String handleForgotPassword(@RequestParam("email") String email, Model model) {
//        User user = userRepository.findByEmail(email);
//
//        if (user == null) {
//            model.addAttribute("message", "No account found with this email.");
//            return "forgotpassword";
//        }
//
//        // Simulate password reset token link (in real app, generate secure token)
//        String resetLink = "http://localhost:8080/resetpassword?email=" + user.getEmail();
//
//        // Send email
//        SimpleMailMessage message = new SimpleMailMessage();
//        message.setTo(user.getEmail());
//        message.setSubject("Password Reset");
//        message.setText("Click this link to reset your password: " + resetLink);
//        mailSender.send(message);
//
//        model.addAttribute("message", "A reset link has been sent to your email.");
//        return "forgotpassword";
//    }
//
//    @GetMapping("/forgotpassword")
//    public String showForgotPasswordForm() {
//        return "forgotpassword";
//    }
}

