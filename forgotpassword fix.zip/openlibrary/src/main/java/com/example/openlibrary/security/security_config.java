package com.example.openlibrary.security;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.authorization.AuthorizationDecision;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.client.userinfo.DefaultOAuth2UserService;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserService;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.stereotype.Component;

import com.example.openlibrary.model.User;
import com.example.openlibrary.repository.UserRepository;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


@EnableWebSecurity
@Configuration
public class security_config {
	
	@Autowired
	private PasswordEncoder passwordEncoder;
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private CustomSuccessHandler customSuccessHandler;

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .authorizeHttpRequests(auth -> auth
                .requestMatchers(
                    "/", "/signup", "/login", "/index",  "/home","/logout",
                 // ✅ allow contact form + submission
                    "/contact", "/contact/send",      
                    "/css/**", "/js/**", "/img/**", "/forgotpassword/**","/forgotpassword2/**","/resetpassword/**"
                    
                ).permitAll()
//                .requestMatchers("/admin/**").hasRole("ADMIN")
//                .requestMatchers("/member/**").hasRole("MEMBER")
                .requestMatchers("/admin/**").access((authentication, context) -> {
                    HttpServletRequest request = context.getRequest();
                    HttpSession session = request.getSession(false);
                    if (session != null) {
                        Object userObj = session.getAttribute("user");
                        if (userObj instanceof User user && "ADMIN".equalsIgnoreCase(user.getRole())) {
                            return new AuthorizationDecision(true);
                        }
                    }
                    return new AuthorizationDecision(false);
                })

//                .requestMatchers("/member/**").access((authentication, context) -> {
//                    HttpServletRequest request = context.getRequest();
//                    HttpSession session = request.getSession(false);
//                    if (session != null) {
//                        Object userObj = session.getAttribute("user");
//                        if (userObj instanceof User user && "MEMBER".equalsIgnoreCase(user.getRole())) {
//                            return new AuthorizationDecision(true);
//                        }
//                    }
//                    return new AuthorizationDecision(false);
//                })
                .anyRequest().authenticated()
//            )
//            .formLogin(form -> form
//                .loginPage("/index")
//                .loginProcessingUrl("/index")
//                .defaultSuccessUrl("/home", true)
//                .permitAll()
//            .formLogin(form -> form
//                    .loginPage("/index")
//                    .loginProcessingUrl("/login")
//                    .successHandler(customSuccessHandler)
//                    .permitAll()
            )
            .oauth2Login(oauth2 -> oauth2
                .loginPage("/index")
                .defaultSuccessUrl("/home", true)
            )
            .logout(logout -> logout
            	    .logoutUrl("/logout")
            	    .logoutSuccessUrl("/index")
            	    .permitAll()
            	    .logoutRequestMatcher(new AntPathRequestMatcher("/logout", "GET"))
            	
            	
            )
            .csrf(csrf -> csrf
                .ignoringRequestMatchers("/contact/send") 
            );

        return http.build();
    }
    
   
    
    @Bean
    public OAuth2UserService<OAuth2UserRequest, OAuth2User> oauth2UserService() {
        return userRequest -> {
            OAuth2User oauth2User = new DefaultOAuth2UserService().loadUser(userRequest);

            // Get user info
            String email = oauth2User.getAttribute("email");
            String name = oauth2User.getAttribute("name");

            // Save to DB if not already saved
            User existingUser = userRepository.findByEmail(email);
            if (existingUser == null) {
                User newUser = new User();
                newUser.setEmail(email);
                newUser.setName(name);
                newUser.setRole("MEMBER");
                userRepository.save(newUser);
            }

            return oauth2User;
        };
    }
    
    @Bean
    public AuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        provider.setUserDetailsService(email -> {
            User user = userRepository.findByEmail(email);
            if (user == null) throw new UsernameNotFoundException("User not found");

            return new org.springframework.security.core.userdetails.User(
                user.getEmail(),
                user.getPassword(),
                List.of(new SimpleGrantedAuthority("ROLE_" + user.getRole().toUpperCase()))
            );
        });
        provider.setPasswordEncoder(passwordEncoder); // ✅ This fixes the error
        return provider;
    }
    
}
