package com.example.openlibrary;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OpenlibraryApplication {

	public static void main(String[] args) {
		SpringApplication.run(OpenlibraryApplication.class, args);
	}

}
