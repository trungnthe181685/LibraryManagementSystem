package com.example.openlibrary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OpenlibraryApplicationTests {

	@Test
	void contextLoads() {
	}

}
